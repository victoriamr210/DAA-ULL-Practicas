
#include "Solucion.h"

Solucion::Solucion() {
}

Solucion::~Solucion() {
}

void Solucion::resolver() {
}

void Solucion::mezcla(pair<Solucion*,Solucion*> subSoluciones) {
}

Solucion* Solucion::getInstance() {
}

