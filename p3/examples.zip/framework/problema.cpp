
#include "Problema.h"

Problema::Problema() {
}

Problema::~Problema() {
}

bool Problema::isCasoMinimo() {
}

pair<Problema*,Problema*> Problema::descomponer() {
}

void Problema::solver(Solucion* s) {
}

